import React from "react";
import { Card } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-800">
      <header className="bg-black text-white py-12 text-center">
        <h1 className="text-4xl font-bold">WL Cyber Cafe</h1>
        <p className="text-lg mt-2">Fast Internet. Affordable Services. Chill Vibes.</p>
      </header>

      <nav className="bg-gray-800 text-white py-3 text-center space-x-6">
        <a href="#services" className="hover:underline">Services</a>
        <a href="#booking" className="hover:underline">Book</a>
        <a href="#contact" className="hover:underline">Contact</a>
      </nav>

      <section id="services" className="py-12 px-6">
        <h2 className="text-2xl text-center font-semibold mb-6">Our Services</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {[
            "High-Speed Internet Access",
            "Xerox Zone",
            "Printing & Scanning",
            "Document Typing",
          ].map((service, idx) => (
            <Card
              key={idx}
              className="p-6 bg-white rounded-2xl shadow-md text-center hover:scale-105 transition-transform"
            >
              {service}
            </Card>
          ))}
        </div>
      </section>

      <section id="booking" className="py-12 px-6 bg-white">
        <h2 className="text-2xl text-center font-semibold mb-6">Book a Slot</h2>
        <div className="text-center">
          <a
            href="https://docs.google.com/forms/d/e/1FAIpQLScBJrEV_wuADlSXrJEWlls5DdjquYVSyEBh1ilvVneB2qo78Q/viewform?usp=dialog"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-black text-white px-6 py-3 rounded-xl hover:bg-gray-900 transition"
          >
            Open Booking Form
          </a>
        </div>
      </section>

      <section id="contact" className="py-12 px-6">
        <h2 className="text-2xl text-center font-semibold mb-6">Contact Us</h2>
        <div className="text-center space-y-2">
          <p>📍 Moowamon Mihmyntdu, Opp DTO Transport Authority, Jowai</p>
          <p>📞 +91 9862746779</p>
          <p>📧 wldigital2020@gmail.com</p>
        </div>
        <div className="mt-6 flex justify-center">
          <iframe
            src="https://www.google.com/maps?q=Moowamon+Mihmyntdu+DTO+Transport+Authority+Jowai&output=embed"
            width="100%"
            height="300"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
          ></iframe>
        </div>
      </section>

      <footer className="bg-black text-white text-center py-6">
        <p>&copy; 2020 WL Cyber Cafe. All rights reserved.</p>
        <div className="flex justify-center space-x-4 mt-4 text-2xl">
          <a href="#" aria-label="Facebook">
            <i className="icon ion-logo-facebook"></i>
          </a>
          <a href="#" aria-label="Instagram">
            <i className="icon ion-logo-instagram"></i>
          </a>
          <a href="#" aria-label="WhatsApp">
            <i className="icon ion-logo-whatsapp"></i>
          </a>
          <a href="#" aria-label="Telegram">
            <i className="icon ion-logo-telegram"></i>
          </a>
        </div>
      </footer>
    </div>
  );
}